from django.contrib import admin
from django.urls import path
from restapp import views

urlpatterns = [
    path('student', views.student), # GET all and POST requests
    path('studentDetails/<sid>',views.studentDetails) #GET by id , PUT , DELETE
]
