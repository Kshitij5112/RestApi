from django.shortcuts import render
from django.http import JsonResponse
from rest_framework.parsers import JSONParser
from django.views.decorators.csrf import csrf_exempt
from restapp.serializers import StudentSerializer
from restapp.models import Students
# Create your views here.
@csrf_exempt
def student(request):
    if request.method=="POST":
        data=JSONParser().parse(request)
        # print(type(data)) #dict
        print(data)
        ser = StudentSerializer(data=data)
        if ser.is_valid():
            ser.save()
            return JsonResponse(ser.data,status=201)
        else:
            return JsonResponse(ser.errors,status=400)
    else:
        data = Students.objects.all()
        ser = StudentSerializer(data,many =True)
        return JsonResponse(ser.data , status=200, safe=False)
def studentDetails(request,sid):
    stu = Students.objects.get(id==sid)
    if stu:
        if request.method=='GET':
            ser=StudentSerializer(stu)
            return JsonResponse(ser.data,status=200)
        elif request.method=='DELETE':
            stu.delete()
            success={'success':'Student deleted'}
            return JsonResponse(success,status=204)
        elif request.method == "PUT":
            data=JSONParser().parse(request)
            ser=StudentSerializer(stu,data=data)
            if ser.is_valid():
                ser.save()
                return JsonResponse(ser.data,status=200)
    else:
        error={'error': 'student id is invalid'}
        return JsonResponse(error,status=404)
